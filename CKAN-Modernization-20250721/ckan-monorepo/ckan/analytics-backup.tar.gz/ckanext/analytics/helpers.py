
def analytics_hello():
    return "Hello, analytics!"


def get_helpers():
    return {
        "analytics_hello": analytics_hello,
    }
